export const API_KEY='AIzaSyB4nNWnT8cCzQDcXJPC8XZ64X4eU2Sdfoo';
export default API_KEY;